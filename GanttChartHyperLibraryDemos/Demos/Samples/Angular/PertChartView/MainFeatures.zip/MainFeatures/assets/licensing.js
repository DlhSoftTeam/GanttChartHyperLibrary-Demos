DlhSoft.Licensing.setLicense("DlhSoft.Controls.GanttChartView", "DlhSoft Internal:1707429600000:10BA1CF96");
DlhSoft.Licensing.setLicense("DlhSoft.Controls.ScheduleChartView", "DlhSoft Internal:1707429600000:1730311CF");
DlhSoft.Licensing.setLicense("DlhSoft.Controls.LoadChartView", "DlhSoft Internal:1707429600000:128C3A0BE");
DlhSoft.Licensing.setLicense("DlhSoft.Controls.Pert.PertChartView", "DlhSoft Internal:1707429600000:5C1348D0");
DlhSoft.Licensing.setLicense("DlhSoft.Controls.Pert.NetworkDiagramView", "DlhSoft Internal:1707429600000:EA6D326");