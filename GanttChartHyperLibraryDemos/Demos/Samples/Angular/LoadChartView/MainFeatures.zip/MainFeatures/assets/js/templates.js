﻿function initializeGanttChartTemplates(settings, theme) {
}
